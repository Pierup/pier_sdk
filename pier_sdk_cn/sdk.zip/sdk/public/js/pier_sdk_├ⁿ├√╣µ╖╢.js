/**
 * pier js sdk 命名规范
 */

1.缩写规范
bk：bank,
cfm: confirm,



2.confirm page 
   row1: 使用credit支付的金额
   row2：分期的选项
   row3：agreement协议
   row4: 银行卡支付，选择银行卡
   row5：支付总的金额
   row6: 美元，银行，汇率
   

